# ChannelPointCollector

Firefox releases are here: https://github.com/WeaselStorm/ChannelPointCollector/tags

Chrome store here: https://chrome.google.com/webstore/detail/channel-point-and-drop-co/ffnpmjlpaidhikgbhnjdhpcjcnlonigg
